let division = new Promise((resolve, reject) => {
    let n1 = 10;
    let n2 = 6;
    if (n2 != 0) {
        resolve(n1/n2)
    } else {
        reject("no se puede dividir por 0")
    }    
});
// console.log(division)
division.then(resultado => console.log("se hizo la division correctamente, resultado: "+resultado)).catch(error => console.log("error: "+error))

function dividir(n1,n2){
    return new Promise((resolve,reject)=> {
        if (n2 != 0) {
            resolve(n1/n2)
        } else {
            reject("no se puede dividir por 0")
        }  
    })
}

dividir(0,0).then(resultado => console.log("se hizo la division correctamente, resultado: "+resultado)).catch(error => console.log("error: "+error))

function esperar(ms){
    return new Promise((resolve, reject) => {
        if (ms <= 0) {
            reject(new Error("no podemos esperar 0 segundos o menos"))
        }
        setTimeout(() => {
            resolve(ms/1000)
        }, ms)
    });
}

esperar(-10).then(segundos => console.log(`esperamos ${segundos} segundos`)).catch(error => console.log(`se produjo un error: ${error.message}`))

// 

let urlApi = "https://pokeapi.co/api/v2/pokemon?limit=100&offset=0";


// fetch(urlApi).then(response => response.json()).then(data => {
//     // throw new Error("no se pudo obtener la informacion de la API")
//     console.log(data)
//     console.log(data.results)
//     console.log(data.results[0])
//     console.log(data.results[0].name)
// }).catch(error => console.log(error));

async function getPokemonData(){
    try {
        // throw new Error("no se pudo obtener la informacion de la API")
        const response = await fetch(urlApi);
        // console.log(response);
        const data = await response.json();
        console.log(data.results)
        crearLista(data.results);
    } catch(error) {
        console.log(`ocurrio un error: ${error.message}`)
    }
}
getPokemonData();

function crearLista(results){
    let HTMLlista = ""
    results.forEach(pokemon => {
        HTMLlista += `<div>
            <p>Nombre: ${pokemon.name}</p>
            <p>URL: <a href="${pokemon.url}">${pokemon.url}</a></p>
        </div>`
    });
    document.querySelector("body").innerHTML = HTMLlista;
}
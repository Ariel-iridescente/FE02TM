/* 
const persona = {
    nombre: 'eduardo',
    apellido:'mendoza'
}

const {nombre, apellido} = persona

console.log(nombre);

persona.nombre */

const { createApp } = Vue

createApp({
    data() {
        return {
            message: 'Hola desde VUE!',
            contador: 0,
            texto : '',
            posibleFoto: null,
            numeros: [1,2,3,4,,6,7,9],
            eventos: [],
        }
    },
    created(){
        console.log('app creada');
        this.posibleFoto = 'https://images.unsplash.com/photo-1593288942460-e321b92a6cde?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8MXx8fGVufDB8fHx8&w=1000&q=80'
    },
    mounted(){
        console.log('vista montada');
    },
    methods:{
        //Todas las funciones
        contar(){
            this.contador++
        },
        borrarTexto(){
            this.texto = ''
        }
    },
    computed:{
        //Propiedades o metodos que dependan de otros
    }
}).mount('#app')